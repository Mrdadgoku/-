<h2 align="center">
    ──「 𝙂𝙤𝙠𝙪 ✘ 𝘼𝙨𝙨𝙞𝙨𝙩𝙖𝙣𝙩 」──

<p align="center">
<a href="https://github.com/WCGKING/KINGUSERBOT"><img src="https://te.legra.ph/file/11cfa74175b590014bd16.jpg" height="270" width="480" alt="Branded-Userbot"/></a>
</p>

<h2 align="center">
    ──「 𝙂𝙤𝙠𝙪 ✘ 𝘼𝙨𝙨𝙞𝙨𝙩𝙖𝙣𝙩 」──
    
    
「[𝙂𝙤𝙠𝙪 ✘ 𝘼𝙨𝙨𝙞𝙨𝙩𝙖𝙣𝙩❤️💣](https://t.me/NezuKo_Assistant_Bot)」



<p align="center">
  <img src="https://graph.org/file/1481a6df3ed3ecfc21cfa.jpg">
</p>


<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>
<h3 align="center">
     ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/WCGKING/KINGUSERBOT"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


[![GIF](https://github.com/WCGKING/WCGKING/blob/main/WCGKING.gif)](https://github.com/WCGKING)
   [![𝙂𝙤𝙠𝙪 ✘ 𝘼𝙨𝙨𝙞𝙨𝙩𝙖𝙣𝙩 ](https://github-stats-alpha.vercel.app/api?username=WCGKING "WCGKING")](https://github-stats-alpha.vercel.app/api?username=WCGKING "WCGKING")


<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://t.me/GOKU_MODZ"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://t.me/NezuKo_Assistant_Bot"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>


<h2>🌐 Updates & Support</h2>
<p title="Support">You can join Genius-Userbot's official Telegram channel and group on Telegram for any Genius-Userbot updates and support-related issues.</p>

- Telegram Channel: [**`@GOKUxEDITION**](https://t.me/GOKU_MODZ)

- 
<h2>📑 Acknowledgement / Credits</h2>

- [**`Pyrogram:`**](https://github.com/pyrogram) All functions of Branded-Userbot based on this mtproto client library.
- [**`Py-TgCalls:`**](https://github.com/py-tgcalls) Streaming system of Branded-Userbot based on this library.




