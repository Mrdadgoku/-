__NAME__ = "History"
__MENU__ = """
`.history` - **Get All Names
and Usernames History.**

**Alternate Command:** '`whois`'
"""
