# Powered By // @BRANDED_PAID_CC //

__NAME__ = "Raids"
__MENU__ = """
**Reply On Target Users Messages
To Activate Or Deactivate.**

`.cr` - Activate Chat Raid.
`.dcr` - De-Activate Chat Raid.

`.fr` - Activate Fuck Raid.
`.dfr` - De-Activate Fuck Raid.

`.lr` - Activate Love Raid.
`.dlr` - De-Activate Love Raid.
"""

